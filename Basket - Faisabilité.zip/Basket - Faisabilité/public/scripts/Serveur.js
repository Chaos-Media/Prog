import {model} from "../../scripts/Application.js";
import {clientConnect} from "../../scripts/Application.js";

const express = require('express');
const http = require('http');

export class Serveur{

    constructor(){

        this.app = express();
        this.serveur = http.createServer(this.app);
        this.io = require('socket.io')(this.serveur);

        this.app.use(express.static('public'));

    }

    demarrer(){

        this.serveur.listen(3000, '192.168.0.138', () => {
            console.log('Le Serveur est prêt');
        });

        this.io.on("connection", socket =>{

            console.log("Connexion d'un client");
            clientConnect= true;
            socket.on("position", this.deplacer.bind(this));

        });

    }

    deplacer(message){

        model.position.y = message.y/-100;
        model.position.x = message.x/100;

        console.log(model.position.x, model.position.y);

    }

}