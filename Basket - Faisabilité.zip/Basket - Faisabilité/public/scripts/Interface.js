export class Interface{

    constructor() {


        this.socket = io("http://192.168.0.138:3000");

        document.body.addEventListener("touchmove", this.gererMouvement.bind(this));

    }

    gererMouvement(e){
        // console.log(e);

        e.touches[0].clientY

        this.socket.emit("position", {x: e.touches[0].clientX, y:e.touches[0].clientY});
    }
}