import {Serveur} from "../public/scripts/Serveur.js";
import {GLTFLoader} from "../bibliotheques/GLTFLoader.js";

let scene, camera, renderer;
let physics_stats, render_stats;
let ground;
let ecouteurTick;
let loader;
export let model, ballonPris, ballonLancer, clientConnect, posBallonInitX, posBallonInitY, posBallonInitZ;

let vector;

let mouse = {x: 0, y: 0}, mouseMesh;

export class Application {

    constructor() {

        Physijs.scripts.worker = '../bibliotheques/physijs_worker.js';
        Physijs.scripts.ammo = 'ammo.js';


        nw.Window.get().showDevTools();

        this.serveur = new Serveur();

        this.serveur.demarrer();

        this.initThreeJS();
        // this.initLoader();

        this.ecouteur = this.bougerBallon.bind(this);


    }

    // initLoader(){
    //
    //     loader = new GLTFLoader();
    //
    //     loader.load( '../ressources/gltf001.glb', function ( gltf ) {
    //
    //         model = gltf.scene.children[2];
    //         scene.add( gltf.scene );
    //
    //     }, undefined, function ( error ) {
    //
    //         console.error( error );
    //
    //     } );
    //
    // }


    initThreeJS() {
        scene = new Physijs.Scene({fixedTimeStep: 1 / 120});
        scene.setGravity(new THREE.Vector3(0, -30, 0));
        scene.addEventListener(
            'update',
            function () {
                scene.simulate(undefined, 2);
                physics_stats.update();
            }
        );

        camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);

        renderer = new THREE.WebGLRenderer({antialias: true});
        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.shadowMap.enabled = true;
        renderer.shadowMapSoft = true;
        document.body.appendChild(renderer.domElement);

        render_stats = new Stats();
        render_stats.domElement.style.position = 'absolute';
        render_stats.domElement.style.top = '0px';
        render_stats.domElement.style.zIndex = 100;
        document.body.appendChild(render_stats.domElement);

        physics_stats = new Stats();
        physics_stats.domElement.style.position = 'absolute';
        physics_stats.domElement.style.top = '50px';
        physics_stats.domElement.style.zIndex = 100;
        document.body.appendChild(physics_stats.domElement);

        this.ajouterElements();
    }

    ajouterElements() {

        //Lumière ambiante

        let ambient = new THREE.AmbientLight(0x000000, 0.3);
        scene.add(ambient)
        let pointLight = new THREE.PointLight(0xffffff, 0.6, 200);
        pointLight.position.set(10, 10, 100);
        pointLight.castShadow = true;
        scene.add(pointLight);

        //Lumière directionnelle

        let dirLight = new THREE.DirectionalLight(0xffffff, 1, 100);
        dirLight.position.set(20, 15, 2);
        dirLight.castShadow = true;
        scene.add(dirLight);

        //Plancher

        let material = new THREE.MeshBasicMaterial({color: 0xbababa});
        ground = new Physijs.BoxMesh(
            new THREE.BoxGeometry(10, 0.1, 10),
            material,
            0 // mass
        );

        ground.position.y = -4;
        ground.position.z = -2;
        ground.receiveShadow = true;
        scene.add(ground);

        //Ballon

        let sphere_geometry = new THREE.SphereGeometry(1.5, 32, 32);

        let materialModel = new THREE.MeshLambertMaterial({color: 0xbababa});
        model = new Physijs.SphereMesh(sphere_geometry, materialModel, undefined, {restitution: Math.random() * 1.5});
        model.position.set(0, 0, 0);

        posBallonInitX = model.position.x;
        posBallonInitY = model.position.y;
        posBallonInitZ = model.position.z;

        scene.add(model);


        camera.position.z = 5;

        this.animate();


        document.addEventListener('mouseup', this.lancerBallon.bind(this));
        document.addEventListener('mousedown', this.prendreBallon.bind(this));


    }


    bougerBallon(event) {

        if (!ballonLancer) {

            event.preventDefault();
            mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
            mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;
            vector = new THREE.Vector3(mouse.x, mouse.y, 0.5);
            vector.unproject(camera);
            let dir = vector.sub(camera.position).normalize();
            let distance = -camera.position.z / dir.z;
            let pos = camera.position.clone().add(dir.multiplyScalar(distance));
            model.position.copy(pos);
            model.__dirtyPosition = true;

        }

    }

    prendreBallon() {
        document.addEventListener('mousemove', this.ecouteur);
    }

    lancerBallon() {

        // console.log(model.position.y, model.position.x, model.position.z);

        if (!ballonLancer) {
            document.removeEventListener('mousemove', this.ecouteur);
            console.log("Ballon Relacher et lancer");

            ballonPris = true;
            ballonLancer = true;

            model.setLinearVelocity(new THREE.Vector3(0, 25, -25));
            model.setAngularVelocity(new THREE.Vector3(0, 1, 0));

            setTimeout(() => {

                model.__dirtyPosition = false;
                model.position.set(posBallonInitX, posBallonInitY, posBallonInitZ);
                ballonPris = false;
                ballonLancer = false;
                model.__dirtyPosition = true;

            }, 5000);

        }
    }

    animate() {
        if (model !== undefined) {

            if (ballonPris !== true) {

                model.__dirtyPosition = true;
                model.setLinearVelocity(new THREE.Vector3(0, 0, 0));
                model.setAngularVelocity(new THREE.Vector3(0, 0, 0));

            }
        }

        scene.simulate();
        renderer.render(scene, camera);
        requestAnimationFrame(this.animate.bind(this));
        render_stats.update();
    }

}